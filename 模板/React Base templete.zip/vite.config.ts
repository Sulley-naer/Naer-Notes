import dev from "./vite.dev.config.ts";
import ser from "./vite.serve.config.ts";
import { defineConfig, loadEnv } from "vite";

export default defineConfig(({ command, mode }) => {
  // 加载当前模式的环境变量
  const env = loadEnv(mode, process.cwd(), "");

  // 基础配置
  const baseConfig = defineConfig({
    server: {
      proxy: {
        '/api': {
          target: env.Client_Url, // 根据 mode 动态获取 Client_Url
          changeOrigin: true,
          rewrite: (path: string) => path.replace(/^\/api/, ''),
          secure: false,
        },
      },
    },
  });

  // 根据 command 和 mode 动态合并配置
  const configResolve = {
    build: (): object => {
      return {
        ...baseConfig,
        ...ser,
      };
    },
    serve: (): object => {
      return {
        ...baseConfig,
        ...dev,
      };
    },
  };

  // 打印调试信息
  console.log(`Mode: ${mode}, Command: ${command}`);
  console.log(`Client URL: ${env.Client_Url}`);

  return configResolve[command]();
});
