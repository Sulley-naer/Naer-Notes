import { defineConfig } from "vite";
import { resolve } from "path";

import react from "@vitejs/plugin-react";
import tailwindcss from "tailwindcss";
import autoprefixer from "autoprefixer";

/** 当前执行 node 命令时文件夹的地址（工作目录） */
const root: string = process.cwd();

/** 路径拼接函数，简化代码 */
const pathResolve = (path: string): string => resolve(root, path);

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  css: {
    postcss: {
      plugins: [tailwindcss, autoprefixer],
    },
  },
  resolve: {
    alias: [
      /** 设置 `@` 指向 `src` 目录 */
      { find: "@", replacement: pathResolve("src") },
      /** 设置 `#` 指向 `types` 目录 */
      { find: "#", replacement: pathResolve("types") },
    ],
  },
  envPrefix:"Client_"
});
