import { useParams } from "react-router";

function UserDetail() {
  const parms: { id?: string } = useParams(); // 使用可选属性类型
  return (
    <>
      <span>欢迎你 {parms.id}</span>
    </>
  );
}

export default UserDetail;
