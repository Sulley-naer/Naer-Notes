import {Outlet} from "react-router";

function Userlayout() {
    return (
        <div >
      <header className = 'text-center' >User Page</header >
      <div style = {{width: "30%", margin: "auto", marginTop: "1em"}} >
        <Outlet />
      </div >
    </div >
    );
}

export default Userlayout;
