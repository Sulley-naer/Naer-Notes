import {Form, Input, Button} from "@nextui-org/react";
import React, {FormEvent} from "react";
import axios from "axios";

console.log(import.meta.env)
export default function App() {
    const [action, setAction] = React.useState(String);

    const submit = (e: FormEvent) => {
        e.preventDefault();
        axios.post("/user").then((r) => console.log(r.data))
    }

    return (
        <Form
            className = 'mx-auto w-full max-w-xs flex flex-col gap-4 '
            validationBehavior = 'native'
            onReset = {() => setAction("reset")}
            onSubmit = {(e) => submit(e)}
        >
      <Input
          isRequired
          errorMessage = 'Please enter a valid username'
          label = 'Username'
          labelPlacement = 'outside'
          name = 'username'
          placeholder = 'Enter your username'
          type = 'text'
      />

      <Input
          isRequired
          errorMessage = 'Please enter a valid password'
          label = 'password'
          labelPlacement = 'outside'
          name = 'pwd'
          placeholder = 'Enter your password'
          type = 'password'
      />
      <div className = 'flex gap-2' >
        <Button color = 'primary' type = 'submit' >
          Submit
        </Button >
        <Button type = 'reset' variant = 'flat' >
          Reset
        </Button >
      </div >
            {action && (
                <div className = 'text-small text-default-500' >
          Action: <code >{action}</code >
        </div >
            )}
    </Form >
    );
}
