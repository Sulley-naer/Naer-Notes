import { Button } from "@nextui-org/react";
import { Link, useNavigate } from "react-router";

function Index() {
  // 路由跳转获取方法
  const Navigate = useNavigate();

  return (
    <div>
      <h1 className="text-center">欢迎来到首页</h1>
      <br />
      <div className="text-center">
        <Button
          color="success"
          size="md"
          className="mt-5"
          onClick={() => Navigate("/user/login")}>
          登录
        </Button>

        <Button color="success" size="md" className="mt-5 mx-4">
          <Link to="/user/131"> 用户中心 </Link>
        </Button>
      </div>
    </div>
  );
}

export default Index;
