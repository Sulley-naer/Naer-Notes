import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { NextUIProvider } from "@nextui-org/react";
import axios from "axios";

import Routes from "./Router.tsx";

import "@/global.css";

// import.meta.env.Client_Url 后端跨域拿取后端地址。

axios.defaults.baseURL = "/api";
// axios.defaults.headers.common['Authorization'] = AUTH_TOKEN;
axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <NextUIProvider>
      <Routes />
    </NextUIProvider>
  </StrictMode>
);
