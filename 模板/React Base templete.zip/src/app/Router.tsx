import { lazy, Suspense } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";

// 动态加载组件
const Index = lazy(() => import("@/Pages/_index"));
const UserLayout = lazy(() => import("@/Pages/user/layout"));
const Login = lazy(() => import("@/Pages/user/login"));
const UserDetail = lazy(() => import("@/Pages/user/welcome"));

function Routers() {
  return (
    <BrowserRouter>
      <Suspense fallback={<div>Loading...</div>}>
        <Routes>
          {/* 根路由 */}
          <Route path="/" index element={<Index />} />
          {/* 嵌套路由 */}
          <Route path="/user" element={<UserLayout />}>
            {/* 子路由 path不要给 `/` */}
            <Route path="login" element={<Login />} />
            <Route path=":id" element={<UserDetail />} />
          </Route>
        </Routes>
      </Suspense>
    </BrowserRouter>
  );
}

export default Routers;
