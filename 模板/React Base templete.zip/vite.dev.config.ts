import {defineConfig} from "vite";
import {resolve} from "path";

import react from "@vitejs/plugin-react";
import tailwindcss from "tailwindcss";
import autoprefixer from "autoprefixer";

const root: string = process.cwd();

const pathResolve = (path: string): string => resolve(root, path);

// https://vite.dev/config/
export default defineConfig({
    plugins: [react()],
    css: {
        postcss: {
            plugins: [tailwindcss, autoprefixer],
        },
    },
    resolve: {
        alias: [
            /** 设置 `@` 指向 `src` 目录 */
            {find: "@", replacement: pathResolve("src")},
            /** 设置 `#` 指向 `types` 目录 */
            {find: "#", replacement: pathResolve("types")},
        ],
    },
    envPrefix:"Client_"
});
